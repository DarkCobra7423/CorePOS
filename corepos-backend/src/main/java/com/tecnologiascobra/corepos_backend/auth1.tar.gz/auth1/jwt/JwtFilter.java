package com.tecnologiascobra.corepos_backend.auth.jwt;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class JwtFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;

    public JwtFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    // Este método decide qué rutas NO deben ser filtradas por este filtro
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        // Permite el acceso sin autenticación a las rutas relacionadas con
        // autenticación y Swagger
        return path.startsWith("/auth") ||
                path.startsWith("/swagger-ui") ||
                path.startsWith("/v3/api-docs");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
            HttpServletResponse response,
            FilterChain chain) throws ServletException, IOException {

        // Obtener el encabezado de autorización de la solicitud HTTP
        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            // Extraer el token JWT
            String token = authHeader.substring(7);

            if (jwtUtil.validateToken(token)) {
                // Extraer el nombre de usuario y roles desde el token
                String username = jwtUtil.extractUsername(token);
                List<String> roles = jwtUtil.extractRoles(token);

                // Depurar los roles extraídos para asegurar que son correctos
                System.out.println("Roles extraídos del token: " + roles);

                // Cambia el mapeo para asegurar el prefijo ROLE_
                var authorities = roles.stream()
                        .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role)
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());

                // Crear el objeto de autenticación
                var authentication = new UsernamePasswordAuthenticationToken(username, null, authorities);

                // Establecer el contexto de seguridad con la autenticación
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        }

        // Continuar con el procesamiento de la solicitud
        chain.doFilter(request, response);
    }
}