package com.tecnologiascobra.corepos_backend.auth.config;

import com.tecnologiascobra.corepos_backend.auth.jwt.JwtFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableMethodSecurity(prePostEnabled = true) // Permite usar anotaciones @PreAuthorize
public class SecurityConfig {

    private final JwtFilter jwtFilter;

    // Constructor para inyectar el filtro JWT
    public SecurityConfig(JwtFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf().disable() // Deshabilitar CSRF (para JWT, no es necesario)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/auth/**", "/swagger-ui/**", "/v3/api-docs/**", "/swagger-ui.html")
                        .permitAll() // Permite acceso a login, registro y Swagger sin autenticación
                        .requestMatchers("/api/articles").hasRole("ADMIN") // Coincide con el formato del controlador
                        // .requestMatchers("/api/articles")
                        // .hasAuthority("ROLE_ADMIN") // Cambiado de hasRole a hasAuthority
                        // .hasRole("ADMIN") // Solo los usuarios con rol ADMIN pueden
                        .anyRequest().authenticated() // Cualquier otra solicitud requiere autenticación
                )
                .sessionManagement(sess -> sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // Usar JWT en
                                                                                                        // lugar de
                                                                                                        // sesiones de
                                                                                                        // Spring
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class); // Añadir filtro JWT antes del
                                                                                         // filtro estándar de
                                                                                         // autenticación

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // Usamos BCrypt para encriptar las contraseñas
    }
}
/*
 * package com.tecnologiascobra.corepos_backend.auth.config;
 * 
 * import com.tecnologiascobra.corepos_backend.auth.jwt.JwtFilter;
 * import org.springframework.context.annotation.Bean;
 * import org.springframework.context.annotation.Configuration;
 * import org.springframework.security.authentication.AuthenticationManager;
 * import
 * org.springframework.security.config.annotation.authentication.configuration.
 * AuthenticationConfiguration;
 * import org.springframework.security.config.annotation.method.configuration.
 * EnableMethodSecurity;
 * import
 * org.springframework.security.config.annotation.web.builders.HttpSecurity;
 * import org.springframework.security.config.http.SessionCreationPolicy;
 * import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
 * import org.springframework.security.crypto.password.PasswordEncoder;
 * import org.springframework.security.web.SecurityFilterChain;
 * import org.springframework.security.web.authentication.
 * UsernamePasswordAuthenticationFilter;
 * 
 * @Configuration
 * 
 * @EnableMethodSecurity(prePostEnabled = true) // Permitir usar
 * anotaciones @PreAuthorize
 * public class SecurityConfig {
 * 
 * private final JwtFilter jwtFilter;
 * 
 * public SecurityConfig(JwtFilter jwtFilter) {
 * this.jwtFilter = jwtFilter;
 * }
 * 
 * @Bean
 * public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
 * http
 * .csrf().disable() // Deshabilitar CSRF
 * .authorizeHttpRequests(auth -> auth
 * .requestMatchers("/auth/**", "/swagger-ui/**", "/v3/api-docs/**",
 * "/swagger-ui.html").permitAll() // Permitir autenticación y Swagger
 * .requestMatchers("/article").hasRole("ADMIN") // Aquí se asegura que solo los
 * usuarios con rol ADMIN puedan acceder
 * .anyRequest().authenticated() // Resto de rutas requiere autenticación
 * )
 * .sessionManagement(sess ->
 * sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // Usar JWT, no
 * sesión
 * .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class); //
 * Añadir el filtro JWT antes del filtro estándar
 * 
 * return http.build();
 * }
 * 
 * @Bean
 * public AuthenticationManager
 * authenticationManager(AuthenticationConfiguration config) throws Exception {
 * return config.getAuthenticationManager();
 * }
 * 
 * @Bean
 * public PasswordEncoder passwordEncoder() {
 * return new BCryptPasswordEncoder();
 * }
 * }
 */