package com.tecnologiascobra.corepos_backend.auth.repository;

import com.tecnologiascobra.corepos_backend.auth.model.Role;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface RoleRepository extends MongoRepository<Role, String> {
    Optional<Role> findByName(String name);
}