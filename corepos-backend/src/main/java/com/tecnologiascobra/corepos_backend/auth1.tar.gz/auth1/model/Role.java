package com.tecnologiascobra.corepos_backend.auth.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.annotation.Id;
import lombok.Data;

@Document(collection = "roles") // Usamos @Document para MongoDB
@Data
public class Role {

    @Id
    private String id;  // MongoDB utiliza String como ID por defecto

    private String name;

    // Constructor sin argumentos
    public Role() {
    }

    // Constructor con nombre de rol
    public Role(String name) {
        this.name = name;
    }

    // Constructor completo (si es necesario)
    public Role(String id, String name) {
        this.id = id;
        this.name = name;
    }
}