package com.tecnologiascobra.corepos_backend.auth.repository;

import com.tecnologiascobra.corepos_backend.auth.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

public interface UserRepository extends MongoRepository<User, String> {
    Optional<User> findByUsername(String username);
}