package com.tecnologiascobra.corepos_backend.auth.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Set;

@Document(collection = "users")
public class User {

    @Id
    private String id; // MongoDB generalmente usa String para IDs

    private String username;
    private String password;
    private Set<Role> roles; // Relación con la clase Role

    // Constructor sin argumentos (requerido por Spring Data MongoDB)
    public User() {}

    // Constructor con parámetros
    public User(String username, String password, Set<Role> roles) {
        this.username = username;
        this.password = password;
        this.roles = roles;
    }

    // Getters y setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Role> getRoles() {
        return roles; // Aquí devolvemos la lista de roles
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
}