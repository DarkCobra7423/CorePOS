package com.tecnologiascobra.corepos_backend.auth.Controller;

import com.tecnologiascobra.corepos_backend.auth.model.Role;
import com.tecnologiascobra.corepos_backend.auth.model.User;
import com.tecnologiascobra.corepos_backend.auth.repository.RoleRepository;
import com.tecnologiascobra.corepos_backend.auth.repository.UserRepository;
import com.tecnologiascobra.corepos_backend.auth.jwt.JwtUtil;
import com.tecnologiascobra.corepos_backend.auth.model.JwtResponse;
import com.tecnologiascobra.corepos_backend.auth.model.LoginRequest;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private RoleRepository roleRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Endpoint para login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        // Validación de credenciales...
        Optional<User> user = userRepo.findByUsername(loginRequest.getUsername());

        if (user.isEmpty() || !passwordEncoder.matches(loginRequest.getPassword(), user.get().getPassword())) {
            return ResponseEntity.status(401).body("Invalid credentials");
        }

        Set<String> roles = user.get().getRoles().stream()
                .map(Role::getName)
                .collect(Collectors.toSet());

        final String token = jwtUtil.generateToken(user.get().getUsername(), roles);

        return ResponseEntity.ok(new JwtResponse(token));
    }

    // Endpoint para registro
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody AuthRequest request) {
        if (userRepo.findByUsername(request.getUsername()).isPresent()) {
            return ResponseEntity.status(400).body("Username already exists.");
        }

        Role defaultRole = roleRepo.findByName("ROLE_SELLER")
                .orElseGet(() -> roleRepo.save(new Role("ROLE_SELLER")));

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRoles(Set.of(defaultRole));
        userRepo.save(user);

        return ResponseEntity.status(201).body("User registered successfully.");
    }

    // (opcional) Auto-creación de roles por defecto
    @PostConstruct
    public void initRoles() {
        if (roleRepo.findByName("ROLE_ADMIN").isEmpty()) {
            roleRepo.save(new Role("ROLE_ADMIN"));
        }
        if (roleRepo.findByName("ROLE_SELLER").isEmpty()) {
            roleRepo.save(new Role("ROLE_SELLER"));
        }
    }
}